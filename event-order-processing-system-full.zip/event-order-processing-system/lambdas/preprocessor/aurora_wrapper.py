import boto3
import os

class AuroraWrapper:
    def __init__(self):
        self.client = boto3.client("rds-data")
        self.cluster_arn = os.environ["CLUSTER_ARN"]
        self.secret_arn = os.environ["SECRET_ARN"]
        self.db_name = os.environ["DB_NAME"]

    def execute_statement(self, sql, params=None):
        return self.client.execute_statement(
            secretArn=self.secret_arn,
            resourceArn=self.cluster_arn,
            database=self.db_name,
            sql=sql,
            parameters=params or []
        )