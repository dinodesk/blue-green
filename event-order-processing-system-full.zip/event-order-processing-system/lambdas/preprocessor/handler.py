from aurora_wrapper import AuroraWrapper

def lambda_handler(event, context):
    # Validate and parse input data
    order_data = event.get("order")

    # Initialize Aurora wrapper
    aurora = AuroraWrapper()

    # Sample SQL
    sql = "INSERT INTO Orders (id, item, quantity) VALUES (:id, :item, :quantity)"
    params = [
        {"name": "id", "value": {"stringValue": order_data["id"]}},
        {"name": "item", "value": {"stringValue": order_data["item"]}},
        {"name": "quantity", "value": {"longValue": int(order_data["quantity"])}}
    ]

    response = aurora.execute_statement(sql, params)
    return {"status": "success", "details": response}