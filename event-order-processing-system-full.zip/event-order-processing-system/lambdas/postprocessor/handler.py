def lambda_handler(event, context):
    for record in event['Records']:
        order_data = record['body']
        # Log and process order
        print(f"Processing order: {order_data}")
    return {"status": "completed"}