resource "aws_apigatewayv2_api" "order_api" {
  name          = "OrderSubmissionAPI"
  protocol_type = "HTTP"
}

resource "aws_apigatewayv2_stage" "default" {
  api_id      = aws_apigatewayv2_api.order_api.id
  name        = "$default"
  auto_deploy = true
}

resource "aws_apigatewayv2_integration" "lambda_integration" {
  api_id           = aws_apigatewayv2_api.order_api.id
  integration_type = "AWS_PROXY"
  integration_uri  = aws_lambda_function.preprocess_lambda.invoke_arn
}

resource "aws_apigatewayv2_route" "order_route" {
  api_id    = aws_apigatewayv2_api.order_api.id
  route_key = "POST /order"
  target    = "integrations/${aws_apigatewayv2_integration.lambda_integration.id}"
}