resource "aws_sns_topic" "order_alerts" {
  name = "OrderAlertsTopic"
}