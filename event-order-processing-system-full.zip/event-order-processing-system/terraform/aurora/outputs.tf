output "aurora_cluster_arn" {
  value = aws_rds_cluster.aurora.arn
}

output "aurora_endpoint" {
  value = aws_rds_cluster.aurora.endpoint
}