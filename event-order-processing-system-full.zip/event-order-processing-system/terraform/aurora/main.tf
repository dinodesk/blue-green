provider "aws" {
  region = var.aws_region
}

resource "aws_rds_cluster" "aurora" {
  engine                    = "aurora-mysql"
  engine_mode               = "serverless"
  engine_version            = "8.0.mysql_aurora.3.04.0"
  database_name             = var.db_name
  master_username           = var.db_username
  master_password           = var.db_password
  db_subnet_group_name      = aws_db_subnet_group.aurora_subnet.name
  vpc_security_group_ids    = [var.aurora_sg_id]
  storage_encrypted         = true
  backup_retention_period   = 1
  deletion_protection       = false
  enable_http_endpoint      = true
  skip_final_snapshot       = true
  apply_immediately         = true
}

resource "aws_db_subnet_group" "aurora_subnet" {
  name       = "aurora-subnet-group"
  subnet_ids = var.private_subnet_ids

  tags = {
    Name = "aurora-subnet-group"
  }
}