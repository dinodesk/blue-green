1. Start Infra (docker-compose)
docker compose up -d
 
 Verify from 
 docker ps

2. Open VSCode in DevContainer

Reopen  in container.

3. STEP 3 — Provision LocalStack Infra

cd terraform
terraform init
terraform apply -auto-approve


verify by 
aws --endpoint-url=http://localstack:4566 sqs list-queues


4. Press F5 for app/main.py

for everything exist
✔ Redis exists
✔ LocalStack exists
✔ Queue exists
✔ AWS session mounted






Open folder ex13/

DevContainer attaches to excalibur service

uvicorn excalibur.api:app keeps container alive

Swagger UI accessible at http://localhost:8000/docs

py -m uvicorn excalibur.api:app --reload --host 127.0.0.1 --port 8000