resource "aws_sqs_queue" "retry" {
  name = "retry-queue"
}