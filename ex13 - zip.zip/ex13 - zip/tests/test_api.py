"""Test suite for Excalibur API."""

import pytest
from fastapi.testclient import TestClient
from excalibur.api import app


client = TestClient(app)


class TestHealthEndpoints:
    """Test health check endpoints."""
    
    def test_root_health_check(self):
        """Test root health check endpoint."""
        response = client.get("/")
        assert response.status_code == 200
        assert response.json()["status"] == "ok"
        assert "Excalibur API running" in response.json()["message"]
    
    def test_health_endpoint(self):
        """Test health endpoint."""
        response = client.get("/health")
        assert response.status_code == 200
        assert response.json()["status"] == "ok"
        assert "healthy" in response.json()["message"].lower()


class TestWorkflowEndpoints:
    """Test workflow endpoints."""
    
    @pytest.mark.asyncio
    def test_invoke_endpoint_exists(self):
        """Test that invoke endpoint exists."""
        response = client.post("/invoke")
        # Will not pass without actual AWS/DynamoDB setup, but endpoint should exist
        assert response.status_code in [200, 500]
    
    @pytest.mark.asyncio
    def test_retry_workflows_endpoint_exists(self):
        """Test that retry-workflows endpoint exists."""
        response = client.post("/retry-workflows")
        # Will not pass without actual SQS setup, but endpoint should exist
        assert response.status_code in [200, 500]
    
    def test_retry_workflows_with_params(self):
        """Test retry-workflows endpoint with query parameters."""
        response = client.post("/retry-workflows?max_messages=5&visibility_timeout=120")
        # Will not pass without actual SQS setup, but endpoint should exist
        assert response.status_code in [200, 500]


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
