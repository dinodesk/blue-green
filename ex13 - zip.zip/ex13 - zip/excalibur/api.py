"""FastAPI application for Excalibur Control Plane with Swagger UI."""

from fastapi import FastAPI, HTTPException, Query
from fastapi.responses import JSONResponse, RedirectResponse
from pydantic import BaseModel
from typing import Optional
import time

app = FastAPI(
    title="⚔️ Excalibur Control Plane",
    description="FastAPI Control Plane for Lambda Workflow Orchestration with DynamoDB, Redis, and SQS",
    version="1.0.0",
    docs_url="/docs",           # Swagger UI at /docs
    # redoc_url="/redoc",         # ReDoc at /redoc
    # openapi_url="/openapi.json" # OpenAPI schema at /openapi.json
)


# ──────────────────────────────────────────────
# Models
# ──────────────────────────────────────────────

class HealthResponse(BaseModel):
    status: str
    uptime_seconds: float
    version: str

START_TIME = time.time()
retry_attempts: dict[str, int] = {}


# ──────────────────────────────────────────────
# Endpoints
# ──────────────────────────────────────────────

@app.get("/", include_in_schema=False)
async def root():
    return RedirectResponse(url="/docs")

@app.get(
    "/healthcheck",
    response_model=HealthResponse,
    tags=["Health"],
    summary="Health Check",
    description="Returns the current health status of the API, including uptime and version.",
)
def healthcheck():
    return HealthResponse(
        status="healthy",
        uptime_seconds=round(time.time() - START_TIME, 2),
        version="1.0.0",
    )

@app.get(
    "/refresh-ids",
    tags=["IDs"],
    summary="Refresh IDs",
    description="Refreshes and returns a new set of IDs for workflow orchestration.",
)
def refresh_ids():
    return {
        "status": "success",
        "message": "IDs refreshed successfully.",
        "timestamp": time.time(),
    }


@app.get(
    "/retry-ids",
    tags=["IDs"],
    summary="Get Retry IDs",
    description="Returns the list of all task IDs currently being tracked for retry.",
)
def retry_ids():
    return {
        "task_ids": list(retry_attempts.keys()),
        "count": len(retry_attempts),
        "timestamp": time.time(),
    }