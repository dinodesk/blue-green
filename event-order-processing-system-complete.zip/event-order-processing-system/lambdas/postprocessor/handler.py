def lambda_handler(event, context):
    for record in event['Records']:
        print(f"Processing order from SQS: {record['body']}")
    return {"status": "done"}