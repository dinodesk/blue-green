from aurora_wrapper import execute_statement

def lambda_handler(event, context):
    print("Received event:", event)
    order = event.get("body")
    sql = "INSERT INTO orders (data) VALUES (:order_data)"
    parameters = [{'name': 'order_data', 'value': {'stringValue': order}}]
    result = execute_statement(sql, parameters)
    return {"statusCode": 200, "body": "Order stored."}
