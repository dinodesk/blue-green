variable "cluster_arn" {}
variable "secret_arn" {}
variable "db_name" {}
variable "subnet_ids" {
  type = list(string)
}
variable "security_group_id" {}