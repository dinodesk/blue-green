resource "aws_lambda_function" "preprocess_lambda" {
  function_name = "PreProcessOrderLambda"
  role          = aws_iam_role.lambda_exec.arn
  runtime       = "python3.11"
  handler       = "handler.lambda_handler"
  filename      = data.archive_file.lambda_pre_zip.output_path
  source_code_hash = data.archive_file.lambda_pre_zip.output_base64sha256
  environment {
    variables = {
      CLUSTER_ARN = var.cluster_arn
      SECRET_ARN  = var.secret_arn
      DB_NAME     = var.db_name
    }
  }
  vpc_config {
    subnet_ids         = var.subnet_ids
    security_group_ids = [var.security_group_id]
  }
}

resource "aws_lambda_function" "postprocess_lambda" {
  function_name = "PostProcessOrderLambda"
  role          = aws_iam_role.lambda_exec.arn
  runtime       = "python3.11"
  handler       = "handler.lambda_handler"
  filename      = data.archive_file.lambda_post_zip.output_path
  source_code_hash = data.archive_file.lambda_post_zip.output_base64sha256
}

resource "aws_iam_role" "lambda_exec" {
  name = "lambda_exec_role"
  assume_role_policy = jsonencode({
    Version = "2012-10-17",
    Statement = [{
      Action = "sts:AssumeRole",
      Principal = {
        Service = "lambda.amazonaws.com"
      },
      Effect = "Allow",
      Sid    = ""
    }]
  })
}

resource "aws_iam_role_policy_attachment" "lambda_policy" {
  role       = aws_iam_role.lambda_exec.name
  policy_arn = "arn:aws:iam::aws:policy/service-role/AWSLambdaVPCAccessExecutionRole"
}

data "archive_file" "lambda_pre_zip" {
  type        = "zip"
  source_dir  = "../../lambdas/preprocessor"
  output_path = "../../lambdas/preprocessor.zip"
}

data "archive_file" "lambda_post_zip" {
  type        = "zip"
  source_dir  = "../../lambdas/postprocessor"
  output_path = "../../lambdas/postprocessor.zip"
}