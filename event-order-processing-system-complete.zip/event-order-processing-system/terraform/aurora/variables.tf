variable "db_name" {}
variable "db_user" {}
variable "db_password" {}
variable "subnet_ids" {
  type = list(string)
}
variable "security_group_id" {}