resource "aws_rds_cluster" "aurora" {
  engine         = "aurora-mysql"
  engine_mode    = "serverless"
  engine_version = "8.0.mysql_aurora.3.04.0"
  database_name  = var.db_name
  master_username = var.db_user
  master_password = var.db_password
  vpc_security_group_ids = [var.security_group_id]
  db_subnet_group_name   = aws_db_subnet_group.aurora_subnets.name
  enable_http_endpoint   = true
  scaling_configuration {
    auto_pause               = true
    min_capacity             = 2
    max_capacity             = 8
    seconds_until_auto_pause = 300
  }
}

resource "aws_db_subnet_group" "aurora_subnets" {
  name       = "aurora-subnets"
  subnet_ids = var.subnet_ids
}