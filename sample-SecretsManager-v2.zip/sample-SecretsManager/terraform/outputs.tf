# output "db_secret_arn" {
#   value = aws_secretsmanager_secret.db.arn
# }

# output "db_user" {
#   value = var.secret_values["dbauthkey"]
# }
output "secret_arn" {
  value = aws_secretsmanager_secret.app.arn
}

output "secret_name" {
  value = aws_secretsmanager_secret.app.name
}

output "non_secret_values" {
  value = var.non_secret_values
}