variable "secret_values" {
  type = map(string)
}
variable "non_secret_values" {
  type = map(string)
}