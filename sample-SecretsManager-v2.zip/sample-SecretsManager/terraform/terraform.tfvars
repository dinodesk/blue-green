secret_values = {
  db_password = "supersecret123"
  dbauthkey   = "abc-xyz-999"
}

non_secret_values = {
  db_user = "admin"
  db_name = "mydatabase"
}