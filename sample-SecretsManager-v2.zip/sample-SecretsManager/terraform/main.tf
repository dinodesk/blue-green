provider "aws" {
  region                      = "us-east-1"
  access_key                  = "test"
  secret_key                  = "test"

  skip_credentials_validation = true
  skip_metadata_api_check     = true
  skip_requesting_account_id  = true

  endpoints {
    secretsmanager = "http://localhost:4566"
  }
}

# resource "aws_secretsmanager_secret" "db" {
#   name = "myapp/db"
# }

# resource "aws_secretsmanager_secret_version" "app_version" {
#   secret_id = aws_secretsmanager_secret.db.id

#   secret_string = jsonencode(var.secret_values)
# }

resource "aws_secretsmanager_secret" "app" {
  name = "myapp/config"
}

resource "aws_secretsmanager_secret_version" "app_version" {
  secret_id     = aws_secretsmanager_secret.app.id
  secret_string = jsonencode(var.secret_values)
}