# FastAPI + Terraform + LocalStack Secrets Manager

This project demonstrates:
- Terraform creating secrets in LocalStack Secrets Manager
- FastAPI fetching secrets at runtime
- Docker Compose running full stack locally

---

## 🧱 Architecture

Terraform → LocalStack Secrets Manager → FastAPI → API endpoint

---

## 📦 Prerequisites

- Docker + Docker Compose
- Terraform
- Python (only if running locally without Docker)

---

## 🚀 Step 1: Start LocalStack

```bash
docker-compose up -d localstack


-----------------
bash generate_env.sh
docker-compose up -d --build api

curl http://localhost:8000/health
$ curl -s http://localhost:4566/_localstack/health


aws --endpoint-url=http://localhost:4566 secretsmanager list-secrets