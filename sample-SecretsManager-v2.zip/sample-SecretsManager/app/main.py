from fastapi import FastAPI
from secret_manager import get_secret,get_nonsecret

app = FastAPI()

@app.get("/health")
def health():
    return {"status": "ok"}

@app.get("/secret")
def secret():
    return get_secret()

@app.get("/non-secret")
def nonsecret():
    return get_nonsecret()