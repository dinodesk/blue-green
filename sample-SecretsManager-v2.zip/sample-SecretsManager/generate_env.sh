#!/bin/bash

set -e

echo "🚀 Starting LocalStack..."
docker-compose up -d localstack

echo "⏳ Waiting for LocalStack..."
sleep 5

echo "⚙️ Running Terraform..."
cd terraform
TF_LOG=DEBUG 
terraform init
terraform apply -auto-approve

ARN=$(terraform output -raw secret_arn)
NON_SECRETS=$(terraform output -json non_secret_values)

cd ..

echo "🧾 Generating .env file..."

cat > .env <<EOF
DB_SECRET_ARN=$ARN
LOCALSTACK_ENDPOINT=http://host.docker.internal:4566
EOF

echo "$NON_SECRETS" | py -c "
import sys, json
data = json.load(sys.stdin)
for k,v in data.items():
    print(f'{k.upper()}={v}')
" >> .env
echo "✅ .env generated successfully"