Run Crawler from AWS Console to catalog the input data.
Start Glue Job manually via the AWS Console or CLI.

 An S3 bucket with folders for input/scripts/temp

✅ A Glue PySpark script uploaded to S3

✅ A DynamoDB table orders with orderid as partition key

✅ A Glue database and crawler to catalog S3 input data

✅ A Glue job that reads CSV, transforms with PySpark, and writes to DynamoDB

✅ IAM roles and policies for Glue to access S3 and DynamoDB