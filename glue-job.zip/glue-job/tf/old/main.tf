terraform {
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.0"
    }
  }

  required_version = ">= 1.3"
}


provider "aws" {
  region = var.region
}

resource "aws_s3_bucket" "data_bucket" {
  bucket_prefix = "${var.bucket_name}-"
  force_destroy = true
}

resource "aws_s3_object" "glue_script" {
  bucket     = aws_s3_bucket.data_bucket.bucket
  source     = "../glue_scripts/transform_to_dynamodb.py"
  key        = "scripts/transform_to_dynamodb.py"
  content_type = "text/x-python"
  etag       = filemd5("../glue_scripts/transform_to_dynamodb.py")
}


resource "aws_dynamodb_table" "orders" {
  name         = var.dynamodb_table_name
  billing_mode = "PAY_PER_REQUEST"
  hash_key     = "orderid"

  attribute {
    name = "orderid"
    type = "S"
  }
}

resource "aws_glue_catalog_database" "orders_db" {
  name = var.glue_db_name
}

resource "aws_glue_crawler" "orders_crawler" {
  name = var.glue_crawler_name
  role = aws_iam_role.glue_role.arn
  database_name = aws_glue_catalog_database.orders_db.name

  s3_target {
    path = "s3://${aws_s3_bucket.data_bucket.bucket}/input/"
  }
}

resource "aws_glue_job" "orders_etl_job" {
  name     = var.glue_job_name
  role_arn = aws_iam_role.glue_role.arn
  glue_version = "4.0"
  number_of_workers = 2
  worker_type = "G.1X"
  command {
    name            = "glueetl"
    script_location = "s3://${aws_s3_bucket.data_bucket.bucket}/scripts/transform_to_dynamodb.py"
    python_version  = "3"
  }
  default_arguments = {
    "--TempDir" = "s3://${aws_s3_bucket.data_bucket.bucket}/temp/"
    "--job-language" = "python"
    "--database" = aws_glue_catalog_database.orders_db.name
    "--table"    = aws_dynamodb_table.orders.name
  }
}

resource "aws_iam_role" "glue_role" {
  name = "glue-dynamodb-etl-role"
  assume_role_policy = jsonencode({
    Version = "2012-10-17",
    Statement = [{
      Action = "sts:AssumeRole",
      Effect = "Allow",
      Principal = {
        Service = "glue.amazonaws.com"
      }
    }]
  })
}

resource "aws_iam_role_policy_attachment" "glue_policy_attach" {
  role       = aws_iam_role.glue_role.name
  policy_arn = "arn:aws:iam::aws:policy/AWSGlueServiceRole"
}

resource "aws_iam_role_policy_attachment" "dynamodb_policy_attach" {
  role       = aws_iam_role.glue_role.name
  policy_arn = "arn:aws:iam::aws:policy/AmazonDynamoDBFullAccess"
}

resource "aws_iam_role_policy_attachment" "s3_policy_attach" {
  role       = aws_iam_role.glue_role.name
  policy_arn = "arn:aws:iam::aws:policy/AmazonS3FullAccess"
}
