output "s3_bucket_name" {
  value = aws_s3_bucket.data_bucket.bucket
}

output "dynamodb_table" {
  value = aws_dynamodb_table.orders.name
}
output "s3_bucket" {
  value = aws_s3_bucket.data_bucket.bucket
}

output "glue_job_name" {
  value = aws_glue_job.orders_etl_job.name
}
