resource "aws_dynamodb_table" "orders" {
  name         = var.table_name
  billing_mode = "PAY_PER_REQUEST"
  hash_key     = "orderid"

  attribute {
    name = "orderid"
    type = "S"
  }
}
