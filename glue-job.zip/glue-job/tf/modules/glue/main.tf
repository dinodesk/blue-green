resource "aws_glue_catalog_database" "orders_db" {
  name = var.glue_db_name
}

resource "aws_glue_crawler" "orders_crawler" {
  name          = var.crawler_name
  role          = var.iam_role_arn
  database_name = aws_glue_catalog_database.orders_db.name
  table_prefix  = "orders_"

  s3_target {
    path = var.input_path
  }
}

resource "aws_glue_job" "orders_etl_job" {
  name              = var.job_name
  role_arn          = var.iam_role_arn
  glue_version      = "4.0"
  number_of_workers = 2
  worker_type       = "G.1X"

  command {
    name            = "glueetl"
    script_location = var.script_s3_path
    python_version  = "3"
  }

  default_arguments = {
    "--TempDir"                           = var.temp_path
    "--job-language"                      = "python"
    "--database"                          = aws_glue_catalog_database.orders_db.name
    "--table"                             = var.dynamodb_table_name
    "--enable-continuous-cloudwatch-log" = "true"
  }
}
