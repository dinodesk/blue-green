variable "glue_db_name" {}
variable "crawler_name" {}
variable "job_name" {}
variable "iam_role_arn" {}
variable "input_path" {}
variable "temp_path" {}
variable "script_s3_path" {}
variable "dynamodb_table_name" {}
