resource "aws_s3_bucket" "data_bucket" {
  bucket = var.bucket_name
  force_destroy = true
}

resource "aws_s3_object" "glue_script" {
  bucket       = aws_s3_bucket.data_bucket.id
  key          = var.script_key
  source       = var.script_path
  content_type = "text/x-python"
  etag         = filemd5(var.script_path)
}
