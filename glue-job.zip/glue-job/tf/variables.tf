variable "region" {
  default = "us-east-1"
}

variable "bucket_name" {
  default = "glue-dynamodb-etl-bucket"
}

variable "dynamodb_table_name" {
  default = "orders_table"
}

variable "glue_db_name" {
  default = "glue_orders_db"
}

variable "glue_crawler_name" {
  default = "orders-crawler"
}

variable "glue_job_name" {
  default = "orders-etl-job"
}
