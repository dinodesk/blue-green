module "s3" {
  source      = "./modules/s3"
  bucket_name = "my-glue-etl-bucket"
  script_key  = "scripts/transform_to_dynamodb.py"
  script_path = "../glue_scripts/transform_to_dynamodb.py"
}

module "dynamodb" {
  source     = "./modules/dynamodb"
  table_name = var.dynamodb_table_name
}

module "iam" {
  source    = "./modules/iam"
  role_name = "glue-dynamodb-etl-role"
}

module "glue" {
  source               = "./modules/glue"
  glue_db_name         = "orders_db"
  crawler_name         = "orders_crawler"
  job_name             = "orders_etl_job"
  iam_role_arn         = module.iam.glue_role_arn
  input_path           = "s3://${module.s3.bucket_name}/input/"
  temp_path            = "s3://${module.s3.bucket_name}/temp/"
  script_s3_path       = "s3://${module.s3.bucket_name}/scripts/transform_to_dynamodb.py"
  dynamodb_table_name  = var.dynamodb.table_name
}
