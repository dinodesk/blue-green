import sys
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from awsglue.context import GlueContext
from pyspark.context import SparkContext
import boto3

args = getResolvedOptions(sys.argv, ['TempDir', 'JOB_NAME', 'database', 'table'])

sc = SparkContext()
glueContext = GlueContext(sc)
spark = glueContext.spark_session

# Read from Glue catalog (created by crawler)
datasource = glueContext.create_dynamic_frame.from_catalog(
    database=args['database'], 
    table_name="input"
)

# Convert to DataFrame for transformation
df = datasource.toDF()

# Transform: cast quantity to int
df_transformed = df.withColumn("quantity", df["quantity"].cast("int"))

# Convert back to DynamicFrame
dyf_transformed = glueContext.create_dynamic_frame.from_dataframe(df_transformed, glueContext)

# Write to DynamoDB
glueContext.write_dynamic_frame_from_options(
    frame=dyf_transformed,
    connection_type="dynamodb",
    connection_options={
        "dynamodb.output.tableName": args['table'],
        "dynamodb.throughput.write.percent": "1.0"
    }
)
