#!/bin/bash

set -e

echo "🚀 Starting LocalStack..."
docker-compose up -d localstack

echo "⏳ Waiting for LocalStack..."
sleep 5

echo "⚙️ Running Terraform..."
cd terraform
TF_LOG=DEBUG 
terraform init
terraform apply -auto-approve

ARN=$(terraform output -raw db_secret_arn)
DB_USER=$(terraform output -raw db_user)

cd ..

echo "🧾 Generating .env file..."

cat > .env <<EOF
DB_SECRET_ARN=$ARN
DB_USER=$DB_USER
LOCALSTACK_ENDPOINT=http://host.docker.internal:4566
EOF

echo "✅ .env generated successfully"