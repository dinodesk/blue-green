import os
import boto3
import json

def get_secret():
    endpoint = os.getenv("LOCALSTACK_ENDPOINT")
    secret_arn = os.getenv("DB_SECRET_ARN")

    client = boto3.client(
        "secretsmanager",
        region_name="us-east-1",
        aws_access_key_id="test",
        aws_secret_access_key="test",
        endpoint_url=endpoint
    )

    response = client.get_secret_value(SecretId=secret_arn)

    return json.loads(response["SecretString"])

def get_nonsecret():
    endpoint = os.getenv("LOCALSTACK_ENDPOINT")
    return json.loads(endpoint)