provider "azurerm" {
  features {}
}

resource "azuread_application" "app" {
  display_name = "vault-token-broker"
}

resource "azuread_service_principal" "sp" {
  client_id = azuread_application.app.application_id
}

resource "azuread_service_principal_password" "secret" {
  service_principal_id = azuread_service_principal.sp.id
}