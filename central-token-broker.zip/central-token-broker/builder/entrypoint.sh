#!/bin/sh

set -e

echo "🔐 Fetching token from Vault..."

TOKEN=$(curl -s \
  -H "X-Vault-Token: $VAULT_TOKEN" \
  $VAULT_ADDR/v1/secret/data/git/azure \
  | jq -r .data.data.token)

if [ "$TOKEN" = "null" ]; then
  echo "❌ No token found in Vault"
  exit 1
fi

echo "📦 Cloning Azure repo..."

git clone https://user:$TOKEN@dev.azure.com/ORG/PROJECT/_git/REPO

echo "✅ Build complete"