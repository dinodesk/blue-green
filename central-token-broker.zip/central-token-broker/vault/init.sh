#!/bin/bash

export VAULT_ADDR=http://127.0.0.1:8200

vault operator init -key-shares=1 -key-threshold=1 > keys.txt

echo "👉 Save keys.txt securely!"

UNSEAL_KEY=$(grep 'Unseal Key 1' keys.txt | awk '{print $4}')
ROOT_TOKEN=$(grep 'Initial Root Token' keys.txt | awk '{print $4}')

vault operator unseal $UNSEAL_KEY

vault login $ROOT_TOKEN

vault secrets enable -path=secret kv-v2