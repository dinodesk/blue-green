from fastapi import FastAPI, HTTPException
import requests
import os

app = FastAPI()

VAULT_ADDR = os.getenv("VAULT_ADDR")
VAULT_TOKEN = os.getenv("VAULT_TOKEN")


def get_secret_from_vault(path):
    url = f"{VAULT_ADDR}/v1/secret/data/{path}"
    headers = {"X-Vault-Token": VAULT_TOKEN}

    r = requests.get(url, headers=headers)

    if r.status_code != 200:
        raise Exception("Vault read failed")

    return r.json()["data"]["data"]


@app.get("/")
def health():
    return {"status": "broker running"}


@app.post("/generate-token")
def generate_token():
    try:
        creds = get_secret_from_vault("azure/oauth")
    except:
        raise HTTPException(status_code=500, detail="❌ Cannot read Azure creds from Vault")

    token_url = f"https://login.microsoftonline.com/{creds['TENANT_ID']}/oauth2/v2.0/token"

    try:
        response = requests.post(token_url, data={
            "client_id": creds["CLIENT_ID"],
            "client_secret": creds["CLIENT_SECRET"],
            "grant_type": "client_credentials",
            "scope": "499b84ac-1321-427f-aa17-267ca6975798/.default"
        })
    except Exception:
        raise HTTPException(status_code=500, detail="❌ Cannot reach Microsoft login endpoint")

    if response.status_code != 200:
        raise HTTPException(status_code=500, detail="❌ Azure OAuth failed")

    access_token = response.json()["access_token"]

    # store in vault
    requests.post(
        f"{VAULT_ADDR}/v1/secret/data/git/azure",
        headers={"X-Vault-Token": VAULT_TOKEN},
        json={"data": {"token": access_token}}
    )

    return {"message": "✅ Token stored in Vault"}