# Central Token Broker System

## Step 1: Start containers

docker-compose up -d --build

---

## Step 2: Initialize Vault

docker exec -it vault sh

vault operator init
vault operator unseal <UNSEAL_KEY>

vault login <ROOT_TOKEN>

vault secrets enable -path=secret kv-v2

---

## Step 3: Store Azure credentials

vault kv put secret/azure/oauth \
  TENANT_ID=xxx \
  CLIENT_ID=xxx \
  CLIENT_SECRET=xxx

---

## Step 4: Open Swagger UI

http://localhost:8000/docs

⚠️ IMPORTANT:
If Vault is NOT unsealed → API will fail

---

## Step 5: Generate token

POST /generate-token

---

## Step 6: Run builder

docker-compose run builder

---

## Troubleshooting

❌ Cannot reach Microsoft login
→ Check internet / firewall

❌ OAuth failed
→ Check Azure credentials

❌ No token in vault
→ Run /generate-token first