from lambda1 import handler

def test_lambda1_publishes_to_sns(monkeypatch):
    events = {'Records': [{'body': 'test message'}]}

    class MockSNS:
        def publish(self, TopicArn, Message):
            assert TopicArn.endswith('lambda1-output-topic')
            assert Message == 'test message'
            return {}

    monkeypatch.setattr('lambda1.sns', MockSNS())
    result = handler(events, None)
    assert result['statusCode'] == 200
