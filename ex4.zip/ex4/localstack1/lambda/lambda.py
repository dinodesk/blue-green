import json
import boto3

sns = boto3.client('sns', endpoint_url='http://localhost:4577')

def handler(event, context):
    for record in event['Records']:
        msg = record['body']
        sns.publish(
            TopicArn='arn:aws:sns:us-east-1:000000000000:lambda1-output-topic',
            Message=msg
        )
    return {"statusCode": 200}
