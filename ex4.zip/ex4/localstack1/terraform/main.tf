provider "aws" {
  region                      = "us-east-1"
  access_key                  = "test"
  secret_key                  = "test"
  skip_credentials_validation = true
  skip_metadata_api_check     = true
  endpoints {
    sns     = "http://localhost:4577"
    sqs     = "http://localhost:4577"
    lambda  = "http://localhost:4577"
  }
}

resource "aws_sqs_queue" "input_queue" {
  name = "lambda1-input-queue"
}

resource "aws_sns_topic" "output_topic" {
  name = "lambda1-output-topic"
}

resource "aws_lambda_function" "lambda1" {
  function_name = "lambda1"
  filename      = "lambda1.zip"
  handler       = "lambda1.handler"
  runtime       = "python3.11"
  role          = "arn:aws:iam::000000000000:role/lambda-role"

  source_code_hash = filebase64sha256("lambda1.zip")
}

resource "aws_lambda_event_source_mapping" "sqs_to_lambda1" {
  event_source_arn = aws_sqs_queue.input_queue.arn
  function_name    = aws_lambda_function.lambda1.arn
  batch_size       = 1
}

output "sns_topic_arn" {
  value = aws_sns_topic.output_topic.arn
}
