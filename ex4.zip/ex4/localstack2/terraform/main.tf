provider "aws" {
  region                      = "us-east-1"
  access_key                  = "test"
  secret_key                  = "test"
  skip_credentials_validation = true
  skip_metadata_api_check     = true
  endpoints {
    sqs     = "http://localhost:4576"
    dynamodb = "http://localhost:4576"
    lambda  = "http://localhost:4576"
  }
}

resource "aws_dynamodb_table" "data_table" {
  name         = "lambda2-data-table"
  billing_mode = "PAY_PER_REQUEST"
  hash_key     = "id"

  attribute {
    name = "id"
    type = "S"
  }
}

resource "aws_sqs_queue" "lambda2_queue" {
  name = "lambda2-input-queue"
}

resource "aws_lambda_function" "lambda2" {
  function_name = "lambda2"
  filename      = "lambda2.zip"
  handler       = "lambda2.handler"
  runtime       = "python3.11"
  role          = "arn:aws:iam::000000000000:role/lambda-role"

  source_code_hash = filebase64sha256("lambda2.zip")
}

resource "aws_lambda_event_source_mapping" "lambda2_sqs_mapping" {
  event_source_arn = aws_sqs_queue.lambda2_queue.arn
  function_name    = aws_lambda_function.lambda2.arn
  batch_size       = 1
}
