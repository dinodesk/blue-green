import json
import boto3
import uuid

dynamodb = boto3.resource('dynamodb', endpoint_url='http://localhost:4576')
table = dynamodb.Table('lambda2-data-table')

def handler(event, context):
    for record in event['Records']:
        msg = record['body']
        table.put_item(Item={'id': str(uuid.uuid4()), 'data': msg})
    return {"statusCode": 200}
