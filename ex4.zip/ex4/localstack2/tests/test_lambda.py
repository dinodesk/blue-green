from lambda2 import handler

def test_lambda2_writes_to_dynamodb(monkeypatch):
    written_items = []

    class MockTable:
        def put_item(self, Item):
            assert 'id' in Item
            assert Item['data'] == 'test message'
            written_items.append(Item)
            return {}

    monkeypatch.setattr('lambda2.table', MockTable())
    result = handler({'Records': [{'body': 'test message'}]}, None)
    assert result['statusCode'] == 200
    assert len(written_items) == 1
