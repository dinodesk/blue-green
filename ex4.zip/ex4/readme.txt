LocalStack1:

Terraform provisions:

Lambda1 (Python)

SNS Topic (Lambda1 publishes to it)

SQS Queue (input to Lambda1)

Lambda1 reads messages from SQS and publishes to SNS.

LocalStack2:

Terraform provisions:

Lambda2 (Python)

SQS Queue (input to Lambda2)

DynamoDB table (Lambda2 writes to it)

Lambda2 reads from SQS and inserts into DynamoDB.

Testing:

pytest tests for both Lambda1 and Lambda2 in their respective projects.



==========================================
cd localstack1 && docker-compose up
cd ../localstack2 && docker-compose up
==========================================
terraform init && terraform apply
=========================================
pip install pytest
cd localstack1/tests && pytest
cd ../../localstack2/tests && pytest
