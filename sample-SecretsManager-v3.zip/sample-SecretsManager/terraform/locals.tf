locals {
  raw_config = var.config
}

# locals {
#   flat_map = merge([
#     for service_name, service in local.raw_config :

#     merge([
#       for key, value in service :

#       # detect object safely using can() instead of length(keys()) which errors on scalars
#       can(keys(value)) ? {

#         for subkey, subval in value :
#         "${upper(service_name)}_${upper(key)}_${upper(subkey)}" => subval

#       } :

#       {
#         "${upper(service_name)}_${upper(key)}" => value
#       }

#     ]...)

#   ]...)
# }
locals {
  flat_map = merge([
    for service_name, service in local.raw_config :
    merge(
      # scalar values: SERVICE_KEY => value
      {
        for key, value in service :
        "${upper(service_name)}_${upper(key)}" => value
        if !can(keys(value))
      },
      # nested object values: SERVICE_KEY_SUBKEY => subval
      merge([
        for key, value in service :
        {
          for subkey, subval in value :
          "${upper(service_name)}_${upper(key)}_${upper(subkey)}" => subval
        }
        if can(keys(value))
      ]...)
    )
  ]...)
}
locals {
  secret_values = {
    for k, v in local.flat_map :
    "${k}_SECRET" => k
    if v == "***"
  }

  non_secret_values = {
    for k, v in local.flat_map :
    k => v
    if v != "***"
  }
}

locals {
  depth_level1 = {
    for k, v in var.config :
    k => (
      can(keys(v)) ? 2 : 1
    )
  }

  depth_level2 = flatten([
    for k, v in var.config :
    can(keys(v)) ? [
      for sk, sv in v :
      can(keys(sv)) ? 3 : 2
    ] : []
  ])

  max_depth = max(
    max(values(local.depth_level1)...),
    length(local.depth_level2) > 0 ? max(local.depth_level2...) : 1
  )
}