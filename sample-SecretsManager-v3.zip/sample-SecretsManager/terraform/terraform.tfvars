secret_values = {
  db_password = "supersecret123"
  app_authkey = "abc-xyz-999"
}

non_secret_values = {
  db_user = "admin"
  db_name = "mydatabase"
}


db = {
  name     = "mydatabase"
  user     = "admin"
  password = "***"
}

cognito = {

  client = "democlient"
  ui     = "https://abc.somewhat.com"
  type   = "client_credential"
  secret = "***"
}

config = {
  db = {
    name     = "mydatabase"
    user     = "admin"
    password = "***"
  }
  cognito = {
    env = {
      name = "dev"
      time = 1
    }

    client = "democlient"
    ui     = "https://abc.somewhat.com"
    type   = "client_credential"
    secret = "***"
  }
  api = {
    url = "https://example.com"
  }
}
