variable "secret_values" {
  type = map(string)
}
variable "non_secret_values" {
  type = map(string)
}

variable "db" {
  type = any
}

variable "cognito" {
  type = any
}

# variable "config" {
#   type = any
#   validation {
#     condition = alltrue([
#       for k, v in var.config :

#       # level 1 or scalar
#       !can(keys(v)) ||

#       # level 2 check only (no deeper nesting allowed)
#       alltrue([
#         for sk, sv in v :
#         !can(keys(sv))
#       ])
#     ])

#     error_message = "config cannot be deeper than 2 levels"
#   }
# }
variable "config" {
  type = any

  validation {
    condition = alltrue([
      for k, v in var.config :

      !can(keys(v)) ||

      alltrue([
        for sk, sv in v :

        !can(keys(sv)) ||

        alltrue(
          can(keys(sv))
          ? [
              for tk, tv in sv :
              !can(keys(tv))
            ]
          : [true]
        )
      ])
    ])

    error_message = "config cannot be deeper than 3 levels (service.key.subkey)"
  }
}